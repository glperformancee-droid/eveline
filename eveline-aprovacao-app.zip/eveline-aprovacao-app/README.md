# Aprovação de Conteúdos — Eveline Zati

Sistema privado para cadastro, revisão e aprovação de conteúdos, com
banco de dados real (Supabase) e login por e-mail/senha. Site estático
(HTML/CSS/JS puro, sem build) pronto para GitHub + Vercel.

## 1. Criar o banco (Supabase — grátis)

1. Crie uma conta em https://supabase.com e um novo projeto.
2. No painel do projeto, vá em **SQL Editor → New query**, cole todo o
   conteúdo do arquivo `schema.sql` deste projeto e clique em **Run**.
3. Vá em **Authentication → Users → Add user** e crie dois usuários
   com e-mail e senha (por exemplo `admin@suaempresa.com` e
   `eveline@suaempresa.com`). Anote o **User UID** de cada um.
4. Volte no **SQL Editor** e rode (trocando pelos UUIDs reais):
   ```sql
   insert into public.profiles (id, role, display_name) values
     ('UUID-DO-ADMIN', 'admin', 'Administrador'),
     ('UUID-DA-EVELINE', 'eveline', 'Eveline Zati');
   ```
5. Vá em **Project Settings → API** e copie a **Project URL** e a
   **anon public key**.

## 2. Configurar o projeto

Abra `config.js` e cole as duas credenciais copiadas no passo anterior:

```js
window.SUPABASE_URL = "https://SEU-PROJETO.supabase.co";
window.SUPABASE_ANON_KEY = "sua-anon-key";
```

A anon key é pública por natureza — quem protege os dados são as
regras de RLS já configuradas no `schema.sql`, não o sigilo dessa chave.

## 3. Subir para o GitHub

```bash
git init
git add .
git commit -m "Sistema de aprovação de conteúdos"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPO.git
git push -u origin main
```

## 4. Deploy na Vercel

1. Em https://vercel.com → **Add New → Project** → importe o
   repositório do GitHub.
2. Framework preset: **Other** (é um site estático, não precisa de
   build). Deixe o *Build Command* e o *Output Directory* em branco.
3. Clique em **Deploy**.

Pronto — a URL da Vercel já estará com login, banco de dados real e
persistência entre recarregamentos.

## Estrutura dos arquivos

- `index.html` — estrutura da página e imports
- `styles.css` — todo o visual (paleta branco / off-white / preto /
  verde militar / dourado fosco, tipografia Poppins)
- `app.js` — lógica da aplicação (autenticação, board semanal,
  aprovação, filtros, indicador de equilíbrio dos públicos etc.)
- `config.js` — onde você cola as credenciais do seu Supabase
- `schema.sql` — tabelas, RLS e (opcional) dados de exemplo

## O que verificar depois do deploy

- Login funciona com os dois usuários criados
- Cadastrar, editar, aprovar, solicitar ajustes e excluir um conteúdo
  persistem de verdade (recarregue a página para confirmar)
- Histórico de cada conteúdo aparece corretamente
- Layout no celular: sem scroll horizontal, abas por dia
- Um usuário não logado não consegue ver nada (teste em aba anônima)

## Limitações desta versão

- Não há cadastro público de usuários — apenas os dois criados
  manualmente no Supabase (por design, é um sistema de 2 pessoas).
- Não há recuperação de senha configurada — se precisar, ative em
  Supabase → Authentication → Providers → Email.
- Sem período personalizado no indicador de equilíbrio (apenas semana
  atual / mês atual), como o MVP original definiu como prioridade.
