/* ============================================================
   SUPABASE CLIENT
   ============================================================ */
const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);

/* ============================================================
   CONSTANTS
   ============================================================ */
const DAYS = ['segunda','quarta','sexta'];
const DAY_LABEL = {segunda:'Segunda-feira', quarta:'Quarta-feira', sexta:'Sexta-feira'};
const AUD_LABEL = {cliente_final:'Cliente Final', mentoria:'Mentoria', conexao:'Conexão'};
const AUD_BADGE_CLASS = {cliente_final:'badge-cliente', mentoria:'badge-mentoria', conexao:'badge-conexao'};
const FORMATS = ['Foto','Carrossel','Reels','Vídeo','Frase','Stories','Outro'];
const STATUS_LABEL = {
  aguardando_aprovacao:'Aguardando aprovação',
  ajustes_solicitados:'Ajustes solicitados',
  aprovado:'Aprovado',
  publicado:'Publicado'
};
const STATUS_CLASS = {
  aguardando_aprovacao:'status-aguardando',
  ajustes_solicitados:'status-ajustes',
  aprovado:'status-aprovado',
  publicado:'status-publicado'
};

/* ============================================================
   STATE
   ============================================================ */
let state = {
  loading:true,
  authError:'',
  authBusy:false,
  session:null,
  role:null, // 'admin' | 'eveline'
  displayName:'',
  contents:[],
  historyCache:{}, // contentId -> [rows]
  filters:{audience:'todos', format:'todos', status:'todos'},
  weekOffset:0,
  balancePeriod:'semana',
  activeDayTab:'segunda',
  modalId:null,
  modalMode:'view',
  modalHistoryLoading:false,
  deleteConfirmId:null,
  draft:null
};

function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(()=>t.classList.remove('show'), 2800);
}

/* ============================================================
   ROW <-> APP OBJECT MAPPING (contents table uses snake_case)
   ============================================================ */
function fromRow(r){
  return {
    id:r.id, title:r.title, weekday:r.weekday, date:r.date,
    audience:r.audience, format:r.format, driveLink:r.drive_link || '',
    caption:r.caption || '', captionSuggestion:r.caption_suggestion || '',
    status:r.status, isSeed:!!r.is_seed
  };
}
function toInsertRow(c){
  return {
    title:c.title, weekday:c.weekday, date:c.date, audience:c.audience,
    format:c.format, drive_link:c.driveLink || null, caption:c.caption || '',
    caption_suggestion:c.captionSuggestion || '', status:c.status, is_seed:false
  };
}

/* ============================================================
   AUTH
   ============================================================ */
async function loadSessionAndProfile(){
  const { data:{ session } } = await supabase.auth.getSession();
  if(!session) return null;
  const { data:profile, error } = await supabase
    .from('profiles').select('role, display_name').eq('id', session.user.id).single();
  if(error || !profile){
    return { session, role:null, displayName:'' };
  }
  return { session, role:profile.role, displayName:profile.display_name || '' };
}

async function doLogin(email, password){
  state.authBusy = true; state.authError=''; render();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if(error){
    state.authBusy=false; state.authError='E-mail ou senha inválidos.'; render();
    return;
  }
  const info = await loadSessionAndProfile();
  if(!info || !info.role){
    state.authBusy=false;
    state.authError='Login ok, mas este usuário não tem um papel (admin/eveline) configurado na tabela profiles.';
    render();
    return;
  }
  state.session = info.session; state.role = info.role; state.displayName = info.displayName;
  state.authBusy=false;
  await bootData();
}

async function doLogout(){
  await supabase.auth.signOut();
  state = { ...state, session:null, role:null, displayName:'', contents:[], modalId:null, modalMode:'view' };
  render();
}

/* ============================================================
   DATA — CONTENTS
   ============================================================ */
async function loadContents(){
  const { data, error } = await supabase.from('contents').select('*').order('date', {ascending:true});
  if(error){ showToast('Erro ao carregar conteúdos.'); return []; }
  return data.map(fromRow);
}

async function insertContent(draft){
  const { data, error } = await supabase.from('contents').insert(toInsertRow(draft)).select().single();
  if(error){ showToast('Erro ao salvar conteúdo.'); return null; }
  await addHistory(data.id, 'criado', 'Conteúdo cadastrado.');
  return fromRow(data);
}

async function updateContentRow(id, patch){
  const row = {};
  if('title' in patch) row.title = patch.title;
  if('weekday' in patch) row.weekday = patch.weekday;
  if('date' in patch) row.date = patch.date;
  if('audience' in patch) row.audience = patch.audience;
  if('format' in patch) row.format = patch.format;
  if('driveLink' in patch) row.drive_link = patch.driveLink;
  if('caption' in patch) row.caption = patch.caption;
  if('captionSuggestion' in patch) row.caption_suggestion = patch.captionSuggestion;
  if('status' in patch) row.status = patch.status;
  row.updated_at = new Date().toISOString();
  const { error } = await supabase.from('contents').update(row).eq('id', id);
  if(error){ showToast('Erro ao salvar alterações.'); return false; }
  return true;
}

async function deleteContentRow(id){
  const { error } = await supabase.from('contents').delete().eq('id', id);
  if(error){ showToast('Erro ao excluir.'); return false; }
  return true;
}

async function addHistory(contentId, type, text){
  const author = state.role==='admin' ? (state.displayName||'Administrador') : (state.displayName||'Eveline Zati');
  const { error } = await supabase.from('content_history').insert({
    content_id: contentId, type, text, author
  });
  if(error) console.error(error);
  delete state.historyCache[contentId];
}

async function loadHistory(contentId){
  if(state.historyCache[contentId]) return state.historyCache[contentId];
  const { data, error } = await supabase
    .from('content_history').select('*').eq('content_id', contentId).order('created_at', {ascending:false});
  if(error){ return []; }
  state.historyCache[contentId] = data;
  return data;
}

/* ============================================================
   DATE / WEEK HELPERS
   ============================================================ */
function startOfWeek(d){
  const dt = new Date(d);
  const day = (dt.getDay()+6)%7;
  dt.setDate(dt.getDate()-day);
  dt.setHours(0,0,0,0);
  return dt;
}
function addDays(d,n){ const r=new Date(d); r.setDate(r.getDate()+n); return r; }
function fmtShort(d){ return d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'}); }
function fmtLong(dstr){
  if(!dstr) return '';
  const d = new Date(dstr+'T00:00:00');
  return d.toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'});
}
function currentWeekRange(offset){
  const today = new Date();
  const mon = addDays(startOfWeek(today), offset*7);
  const sun = addDays(mon,6);
  return {start:mon, end:sun};
}
function inRange(dateStr, start, end){
  if(!dateStr) return false;
  const d = new Date(dateStr+'T00:00:00');
  return d>=start && d<= new Date(end.getFullYear(),end.getMonth(),end.getDate(),23,59,59);
}

/* ============================================================
   DERIVED DATA
   ============================================================ */
function filteredContents(){
  return state.contents.filter(c=>{
    if(state.filters.audience!=='todos' && c.audience!==state.filters.audience) return false;
    if(state.filters.format!=='todos' && c.format!==state.filters.format) return false;
    if(state.filters.status!=='todos' && c.status!==state.filters.status) return false;
    return true;
  });
}
function boardWeekRange(){ return currentWeekRange(state.weekOffset); }
function boardContents(){
  const {start,end} = boardWeekRange();
  return filteredContents().filter(c=>inRange(c.date,start,end));
}
function kpiData(){
  const items = boardContents();
  return {
    total: items.length,
    aguardando: items.filter(c=>c.status==='aguardando_aprovacao').length,
    ajustes: items.filter(c=>c.status==='ajustes_solicitados').length,
    aprovado: items.filter(c=>c.status==='aprovado' || c.status==='publicado').length
  };
}
function balanceData(){
  let start,end;
  if(state.balancePeriod==='semana'){
    const r = currentWeekRange(0); start=r.start; end=r.end;
  } else {
    const today=new Date();
    start = new Date(today.getFullYear(), today.getMonth(),1);
    end = new Date(today.getFullYear(), today.getMonth()+1,0);
  }
  const items = state.contents.filter(c=>inRange(c.date,start,end));
  const counts = {cliente_final:0, mentoria:0, conexao:0};
  items.forEach(c=>{ if(counts[c.audience]!==undefined) counts[c.audience]++; });
  return {counts, total: items.length};
}

/* ============================================================
   RENDER HELPERS
   ============================================================ */
function el(html){ const d=document.createElement('div'); d.innerHTML=html.trim(); return d.firstElementChild; }
function escapeHtml(s){
  return (s||'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function render(){
  const root = document.getElementById('root');
  if(state.loading){
    root.innerHTML = `<div class="loading-screen"><span class="spinner"></span> Carregando painel…</div>`;
    return;
  }
  if(!state.session || !state.role){
    root.innerHTML = renderLoginGate();
    bindLoginGate();
    return;
  }
  root.innerHTML = renderApp();
  bindApp();
  if(state.modalId || state.modalMode!=='view') renderModal();
}

/* ---------- Login gate ---------- */
function renderLoginGate(){
  return `
  <div class="gate">
    <div class="gate-card">
      <p class="brand-eyebrow">Sistema privado</p>
      <h1 class="brand-title" style="font-size:20px;margin-bottom:4px;">Aprovação de Conteúdos</h1>
      <p class="brand-sub" style="margin-bottom:22px;">Entre com seu e-mail e senha.</p>
      <div class="gate-field">
        <span class="field-label">E-mail</span>
        <input class="input-text" id="login-email" type="email" placeholder="voce@exemplo.com">
      </div>
      <div class="gate-field">
        <span class="field-label">Senha</span>
        <input class="input-text" id="login-password" type="password" placeholder="••••••••">
      </div>
      ${state.authError? `<p class="error-text">${escapeHtml(state.authError)}</p>`:''}
      <button class="btn btn-primary" id="login-btn" ${state.authBusy?'disabled':''}>${state.authBusy?'Entrando…':'Entrar'}</button>
      <p class="hint" style="margin-top:16px;">Os usuários são criados no painel do Supabase pelo administrador do sistema, não há cadastro público.</p>
    </div>
  </div>`;
}
function bindLoginGate(){
  const btn = document.getElementById('login-btn');
  const submit = ()=>{
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    if(!email || !password){ state.authError='Preencha e-mail e senha.'; render(); return; }
    doLogin(email, password);
  };
  btn.addEventListener('click', submit);
  document.getElementById('login-password').addEventListener('keydown', e=>{ if(e.key==='Enter') submit(); });
}

/* ---------- Main app ---------- */
function renderApp(){
  const kpi = kpiData();
  const bal = balanceData();
  const wk = boardWeekRange();
  return `
  <div class="wrap">
    ${renderTopbar()}
    <div class="kpi-row">
      <div class="kpi-card"><div class="kpi-num">${kpi.total}</div><div class="kpi-label">Conteúdos da semana</div></div>
      <div class="kpi-card"><div class="kpi-num">${kpi.aguardando}</div><div class="kpi-label">Aguardando aprovação</div></div>
      <div class="kpi-card"><div class="kpi-num">${kpi.ajustes}</div><div class="kpi-label">Ajustes solicitados</div></div>
      <div class="kpi-card"><div class="kpi-num">${kpi.aprovado}</div><div class="kpi-label">Aprovados</div></div>
    </div>
    ${renderRibbon(bal)}
    ${renderFilters()}
    <div class="week-nav">
      <div class="week-nav-btns">
        <button class="week-nav-btn" id="wk-prev">‹</button>
        <button class="week-nav-btn" id="wk-next">›</button>
      </div>
      <div class="week-nav-label">${fmtShort(wk.start)} — ${fmtShort(wk.end)}${state.weekOffset===0?' · semana atual':''}</div>
      <div style="width:66px"></div>
    </div>
    ${renderDayTabs()}
    ${renderBoard()}
  </div>`;
}

function renderTopbar(){
  const roleLabel = state.role==='admin' ? 'Administrador' : 'Eveline Zati';
  return `
  <div class="topbar">
    <div>
      <p class="brand-eyebrow">Painel privado</p>
      <h1 class="brand-title">Aprovação de Conteúdos</h1>
      <p class="brand-sub">Eveline Zati — planejamento, revisão e aprovação</p>
    </div>
    <div class="topbar-actions">
      <div class="role-switch">
        <span class="role-pill active">${roleLabel}</span>
      </div>
      ${state.role==='admin' ? `<button class="btn btn-primary" id="btn-new">+ Novo conteúdo</button>` : ''}
      <button class="btn-text" id="btn-logout">Sair</button>
    </div>
  </div>`;
}

function renderRibbon(bal){
  const {counts,total} = bal;
  const pct = k => total? Math.round((counts[k]/total)*100) : 0;
  return `
  <div class="ribbon-card">
    <div class="ribbon-head">
      <span class="ribbon-title">Equilíbrio dos públicos</span>
      <div class="period-switch">
        <button class="period-btn ${state.balancePeriod==='semana'?'active':''}" data-period="semana">Semana atual</button>
        <button class="period-btn ${state.balancePeriod==='mes'?'active':''}" data-period="mes">Mês atual</button>
      </div>
    </div>
    ${total===0 ? `<p class="ribbon-empty">Nenhum conteúdo com data neste período ainda.</p>` : `
    <div class="ribbon-bar">
      <div class="ribbon-seg seg-cliente" style="width:${pct('cliente_final')}%"></div>
      <div class="ribbon-seg seg-mentoria" style="width:${pct('mentoria')}%"></div>
      <div class="ribbon-seg seg-conexao" style="width:${pct('conexao')}%"></div>
    </div>
    <div class="ribbon-legend">
      <span class="legend-item"><span class="legend-dot seg-cliente"></span>Cliente Final <b>${counts.cliente_final}</b></span>
      <span class="legend-item"><span class="legend-dot seg-mentoria"></span>Mentoria <b>${counts.mentoria}</b></span>
      <span class="legend-item"><span class="legend-dot seg-conexao"></span>Conexão <b>${counts.conexao}</b></span>
    </div>`}
  </div>`;
}

function renderFilters(){
  const f = state.filters;
  const anyActive = f.audience!=='todos'||f.format!=='todos'||f.status!=='todos';
  return `
  <div class="filters-row">
    <select class="filter-select" id="f-audience">
      <option value="todos" ${f.audience==='todos'?'selected':''}>Todos os públicos</option>
      <option value="cliente_final" ${f.audience==='cliente_final'?'selected':''}>Cliente Final</option>
      <option value="mentoria" ${f.audience==='mentoria'?'selected':''}>Mentoria</option>
      <option value="conexao" ${f.audience==='conexao'?'selected':''}>Conexão</option>
    </select>
    <select class="filter-select" id="f-format">
      <option value="todos" ${f.format==='todos'?'selected':''}>Todos os formatos</option>
      ${FORMATS.map(fm=>`<option value="${fm}" ${f.format===fm?'selected':''}>${fm}</option>`).join('')}
    </select>
    <select class="filter-select" id="f-status">
      <option value="todos" ${f.status==='todos'?'selected':''}>Todos os status</option>
      ${Object.entries(STATUS_LABEL).map(([k,v])=>`<option value="${k}" ${f.status===k?'selected':''}>${v}</option>`).join('')}
    </select>
    ${anyActive?`<button class="filter-clear" id="f-clear">Limpar filtros</button>`:''}
  </div>`;
}

function renderDayTabs(){
  return `
  <div class="day-tabs">
    ${DAYS.map(d=>`<button class="day-tab ${state.activeDayTab===d?'active':''}" data-day-tab="${d}">${DAY_LABEL[d].split('-')[0]}</button>`).join('')}
  </div>`;
}

function renderBoard(){
  const items = boardContents();
  return `
  <div class="board">
    ${DAYS.map(day=>{
      const dayItems = items.filter(c=>c.weekday===day);
      return `
      <div class="day-col ${state.activeDayTab===day?'active':''}" data-daycol="${day}">
        <div class="day-col-head">
          <span class="day-col-title">${DAY_LABEL[day]}</span>
          <span class="day-col-count">${dayItems.length}</span>
        </div>
        <div class="day-col-body">
          ${dayItems.length===0 ? `<div class="empty-col">Nada programado ainda.${state.role==='admin'?' Toque em "Novo conteúdo" para adicionar.':''}</div>` :
            dayItems.map(c=>renderCard(c)).join('')}
        </div>
      </div>`;
    }).join('')}
  </div>`;
}

function renderCard(c){
  const pending = c.status==='ajustes_solicitados';
  return `
  <div class="card" data-open="${c.id}">
    ${pending?'<span class="pending-dot" title="Ajustes pendentes"></span>':''}
    <p class="card-title">${escapeHtml(c.title)}</p>
    <div class="card-badges">
      <span class="badge ${AUD_BADGE_CLASS[c.audience]}">${AUD_LABEL[c.audience]}</span>
      <span class="badge badge-format">${c.format}</span>
    </div>
    <div class="card-foot">
      <span class="status-pill ${STATUS_CLASS[c.status]}">${STATUS_LABEL[c.status]}</span>
      ${c.isSeed?'<span class="seed-tag">exemplo</span>':'<span></span>'}
    </div>
  </div>`;
}

/* ============================================================
   MODAL
   ============================================================ */
async function openModal(id){
  state.modalId=id; state.modalMode='view'; state.deleteConfirmId=null;
  state.modalHistoryLoading = true;
  render();
  await loadHistory(id);
  state.modalHistoryLoading = false;
  render();
}
function openNew(){
  state.draft = {title:'', weekday:'segunda', date:'', audience:'cliente_final', format:'Foto', driveLink:'', caption:''};
  state.modalMode='new'; state.modalId=null; render();
}
function openEdit(c){
  state.draft = {...c}; state.modalMode='edit'; state.modalId=c.id; render();
}
function closeModal(){ state.modalId=null; state.modalMode='view'; state.draft=null; render(); }

function renderModal(){
  const overlay = el(`<div class="overlay show"><div class="modal" id="modal-inner"></div></div>`);
  document.body.appendChild(overlay);
  const inner = overlay.querySelector('#modal-inner');

  if(state.modalMode==='new' || state.modalMode==='edit'){
    inner.innerHTML = renderFormModal();
    bindFormModal(overlay);
  } else {
    const c = state.contents.find(x=>x.id===state.modalId);
    if(!c){ overlay.remove(); return; }
    inner.innerHTML = renderDetailModal(c);
    bindDetailModal(overlay, c);
  }
  overlay.addEventListener('click', e=>{ if(e.target===overlay) closeModal(); });
}

function renderDetailModal(c){
  const pendingNote = state.role==='admin' && c.status==='ajustes_solicitados';
  const history = state.historyCache[c.id] || [];
  return `
  <div class="modal-head">
    <div>
      <p class="modal-eyebrow">${AUD_LABEL[c.audience]} · ${c.format}</p>
      <h2 class="modal-title">${escapeHtml(c.title)}</h2>
    </div>
    <button class="modal-close" id="m-close">✕</button>
  </div>
  <div class="modal-body">
    <div class="modal-meta-row">
      <span class="status-pill ${STATUS_CLASS[c.status]}">${STATUS_LABEL[c.status]}</span>
      <span class="badge badge-format">${DAY_LABEL[c.weekday]}${c.date?' · '+fmtLong(c.date):''}</span>
    </div>

    ${c.driveLink ? `<div class="field-block">
      <a class="link-btn" href="${escapeHtml(c.driveLink)}" target="_blank" rel="noopener">↗ Visualizar conteúdo no Drive</a>
    </div>` : `<p class="hint" style="margin-bottom:20px;">Nenhum link do Google Drive cadastrado ainda.</p>`}

    <div class="field-block">
      <span class="field-label">Legenda atual</span>
      <div class="caption-box">${c.caption ? escapeHtml(c.caption) : 'Nenhuma legenda cadastrada ainda.'}</div>
      ${state.role==='admin' ? `<button class="btn btn-ghost btn-sm" style="margin-top:10px;" id="m-edit-caption">Editar legenda</button>` : ''}
    </div>

    ${c.captionSuggestion ? `<div class="field-block">
      <span class="field-label">Sugestão de legenda (Eveline)</span>
      <div class="caption-box" style="background:var(--c-gold-tint);">${escapeHtml(c.captionSuggestion)}</div>
      ${state.role==='admin' ? `<button class="btn btn-ghost btn-sm" style="margin-top:10px;" id="m-apply-suggestion">Usar esta sugestão como legenda</button>` : ''}
    </div>` : ''}

    ${state.role==='eveline' ? `<div class="field-block">
      <span class="field-label">Sugerir alteração na legenda</span>
      <textarea class="input-area" id="m-suggestion-input" placeholder="Escreva aqui a versão que você gostaria...">${escapeHtml(c.captionSuggestion||'')}</textarea>
      <button class="btn btn-ghost btn-sm" style="margin-top:10px;" id="m-save-suggestion">Salvar sugestão</button>
    </div>` : ''}

    ${state.role==='eveline' ? `<div class="field-block">
      <span class="field-label">Observações e ajustes</span>
      <textarea class="input-area" id="m-adjust-input" placeholder="Ex: gostaria de alterar este trecho da legenda..."></textarea>
      <div class="action-row">
        <button class="btn btn-primary btn-sm" id="m-approve">✓ Aprovar</button>
        <button class="btn btn-danger btn-sm" id="m-request-adjust">Solicitar ajustes</button>
      </div>
    </div>` : ''}

    ${state.role==='admin' ? `<div class="field-block">
      <span class="field-label">Ações do administrador</span>
      <div class="action-row">
        <button class="btn btn-ghost btn-sm" id="m-edit-content">Editar conteúdo</button>
        ${c.status==='aprovado' ? `<button class="btn btn-primary btn-sm" id="m-mark-published">Marcar como publicado</button>` : ''}
        <button class="btn btn-danger btn-sm" id="m-delete">${state.deleteConfirmId===c.id?'Confirmar exclusão':'Excluir'}</button>
      </div>
      ${pendingNote?`<p class="hint" style="margin-top:10px;">Eveline solicitou ajustes neste conteúdo — veja o histórico abaixo.</p>`:''}
    </div>` : ''}

    <div class="field-block">
      <span class="field-label">Histórico</span>
      <div class="history-list">
        ${state.modalHistoryLoading ? '<p class="hint">Carregando histórico…</p>' :
          (history.map(h=>`
            <div class="history-item">
              <div class="h-meta">${escapeHtml(h.author)} · ${new Date(h.created_at).toLocaleString('pt-BR')}</div>
              <div class="h-text">${escapeHtml(h.text)}</div>
            </div>`).join('') || '<p class="hint">Sem histórico ainda.</p>')}
      </div>
    </div>
  </div>`;
}

function bindDetailModal(overlay, c){
  overlay.querySelector('#m-close').addEventListener('click', closeModal);

  const editCaptionBtn = overlay.querySelector('#m-edit-caption');
  if(editCaptionBtn) editCaptionBtn.addEventListener('click', ()=>{
    const box = overlay.querySelector('.caption-box');
    const ta = el(`<textarea class="input-area">${escapeHtml(c.caption)}</textarea>`);
    box.replaceWith(ta);
    editCaptionBtn.textContent = 'Salvar legenda';
    editCaptionBtn.addEventListener('click', async ()=>{
      const val = ta.value.trim();
      const ok = await updateContentRow(c.id, {caption:val});
      if(ok){
        c.caption = val;
        await addHistory(c.id,'legenda','Legenda editada pelo administrador.');
        showToast('Legenda salva.');
      }
      openModal(c.id);
    }, {once:true});
  });

  const applySugg = overlay.querySelector('#m-apply-suggestion');
  if(applySugg) applySugg.addEventListener('click', async ()=>{
    const ok = await updateContentRow(c.id, {caption:c.captionSuggestion, captionSuggestion:''});
    if(ok){
      c.caption = c.captionSuggestion; c.captionSuggestion='';
      await addHistory(c.id,'legenda','Sugestão da Eveline aplicada como legenda oficial.');
      showToast('Legenda atualizada.');
    }
    openModal(c.id);
  });

  const saveSugg = overlay.querySelector('#m-save-suggestion');
  if(saveSugg) saveSugg.addEventListener('click', async ()=>{
    const v = overlay.querySelector('#m-suggestion-input').value.trim();
    const ok = await updateContentRow(c.id, {captionSuggestion:v});
    if(ok){
      c.captionSuggestion = v;
      await addHistory(c.id,'sugestao', v? 'Sugeriu uma nova versão da legenda.' : 'Removeu a sugestão de legenda.');
      showToast('Sugestão salva.');
    }
    openModal(c.id);
  });

  const approveBtn = overlay.querySelector('#m-approve');
  if(approveBtn) approveBtn.addEventListener('click', async ()=>{
    const ok = await updateContentRow(c.id, {status:'aprovado'});
    if(ok){
      c.status='aprovado';
      await addHistory(c.id,'aprovado','Conteúdo aprovado.');
      showToast('Conteúdo aprovado.');
    }
    openModal(c.id);
  });

  const reqBtn = overlay.querySelector('#m-request-adjust');
  if(reqBtn) reqBtn.addEventListener('click', async ()=>{
    const v = overlay.querySelector('#m-adjust-input').value.trim();
    if(!v){ showToast('Escreva uma observação antes de solicitar ajustes.'); return; }
    const ok = await updateContentRow(c.id, {status:'ajustes_solicitados'});
    if(ok){
      c.status='ajustes_solicitados';
      await addHistory(c.id,'ajustes', v);
      showToast('Ajustes solicitados.');
    }
    openModal(c.id);
  });

  const editContentBtn = overlay.querySelector('#m-edit-content');
  if(editContentBtn) editContentBtn.addEventListener('click', ()=> openEdit(c));

  const pubBtn = overlay.querySelector('#m-mark-published');
  if(pubBtn) pubBtn.addEventListener('click', async ()=>{
    const ok = await updateContentRow(c.id, {status:'publicado'});
    if(ok){
      c.status='publicado';
      await addHistory(c.id,'publicado','Conteúdo marcado como publicado.');
      showToast('Marcado como publicado.');
    }
    openModal(c.id);
  });

  const delBtn = overlay.querySelector('#m-delete');
  if(delBtn) delBtn.addEventListener('click', async ()=>{
    if(state.deleteConfirmId===c.id){
      const ok = await deleteContentRow(c.id);
      if(ok){
        state.contents = state.contents.filter(x=>x.id!==c.id);
        showToast('Conteúdo excluído.');
        closeModal();
      } else { openModal(c.id); }
    } else {
      state.deleteConfirmId = c.id;
      openModal(c.id);
    }
  });
}

function renderFormModal(){
  const d = state.draft;
  const isEdit = state.modalMode==='edit';
  return `
  <div class="modal-head">
    <div>
      <p class="modal-eyebrow">${isEdit?'Editar conteúdo':'Novo conteúdo'}</p>
      <h2 class="modal-title">${isEdit? escapeHtml(d.title||'Editar') : 'Cadastrar publicação'}</h2>
    </div>
    <button class="modal-close" id="m-close">✕</button>
  </div>
  <div class="modal-body">
    <div class="form-grid">
      <div class="span2">
        <span class="field-label">Título *</span>
        <input class="input-text" id="f-title" value="${escapeHtml(d.title)}" placeholder="Ex: Duas pessoas podem ter o mesmo peso">
      </div>
      <div>
        <span class="field-label">Dia da semana *</span>
        <select class="input-text" id="f-weekday">
          ${DAYS.map(day=>`<option value="${day}" ${d.weekday===day?'selected':''}>${DAY_LABEL[day]}</option>`).join('')}
        </select>
      </div>
      <div>
        <span class="field-label">Data *</span>
        <input class="input-text" type="date" id="f-date" value="${d.date}">
      </div>
      <div>
        <span class="field-label">Público estratégico *</span>
        <select class="input-text" id="f-audience-in">
          ${Object.entries(AUD_LABEL).map(([k,v])=>`<option value="${k}" ${d.audience===k?'selected':''}>${v}</option>`).join('')}
        </select>
      </div>
      <div>
        <span class="field-label">Formato *</span>
        <select class="input-text" id="f-format-in">
          ${FORMATS.map(fm=>`<option value="${fm}" ${d.format===fm?'selected':''}>${fm}</option>`).join('')}
        </select>
      </div>
      <div class="span2">
        <span class="field-label">Link do Google Drive</span>
        <input class="input-text" id="f-link" value="${escapeHtml(d.driveLink)}" placeholder="https://drive.google.com/...">
      </div>
      <div class="span2">
        <span class="field-label">Legenda</span>
        <textarea class="input-area" id="f-caption" placeholder="Escreva a legenda deste conteúdo...">${escapeHtml(d.caption)}</textarea>
      </div>
      <div class="span2" id="f-error"></div>
    </div>
    <div class="action-row">
      <button class="btn btn-primary" id="f-save">${isEdit?'Salvar alterações':'Cadastrar conteúdo'}</button>
      <button class="btn btn-ghost" id="f-cancel">Cancelar</button>
    </div>
  </div>`;
}

function bindFormModal(overlay){
  overlay.querySelector('#m-close').addEventListener('click', closeModal);
  overlay.querySelector('#f-cancel').addEventListener('click', closeModal);
  overlay.querySelector('#f-save').addEventListener('click', async ()=>{
    const title = overlay.querySelector('#f-title').value.trim();
    const weekday = overlay.querySelector('#f-weekday').value;
    const date = overlay.querySelector('#f-date').value;
    const audience = overlay.querySelector('#f-audience-in').value;
    const format = overlay.querySelector('#f-format-in').value;
    const driveLink = overlay.querySelector('#f-link').value.trim();
    const caption = overlay.querySelector('#f-caption').value.trim();

    const errBox = overlay.querySelector('#f-error');
    const errs = [];
    if(!title) errs.push('Título é obrigatório.');
    if(!date) errs.push('Data é obrigatória.');
    if(driveLink && !/^https?:\/\//i.test(driveLink)) errs.push('Link do Drive precisa começar com http:// ou https://');
    if(errs.length){ errBox.innerHTML = errs.map(e=>`<p class="error-text">${e}</p>`).join(''); return; }

    if(state.modalMode==='new'){
      const created = await insertContent({title, weekday, date, audience, format, driveLink, caption, status:'aguardando_aprovacao'});
      if(created){
        state.contents.push(created);
        showToast('Conteúdo cadastrado.');
        closeModal();
      }
    } else {
      const ok = await updateContentRow(state.modalId, {title, weekday, date, audience, format, driveLink, caption});
      if(ok){
        const c = state.contents.find(x=>x.id===state.modalId);
        Object.assign(c, {title, weekday, date, audience, format, driveLink, caption});
        await addHistory(c.id,'editado','Detalhes do conteúdo editados pelo administrador.');
        showToast('Alterações salvas.');
        openModal(c.id);
      }
    }
  });
}

/* ============================================================
   APP-LEVEL BINDINGS
   ============================================================ */
function bindApp(){
  const newBtn = document.getElementById('btn-new');
  if(newBtn) newBtn.addEventListener('click', openNew);

  const logoutBtn = document.getElementById('btn-logout');
  if(logoutBtn) logoutBtn.addEventListener('click', doLogout);

  const wkPrev = document.getElementById('wk-prev');
  const wkNext = document.getElementById('wk-next');
  if(wkPrev) wkPrev.addEventListener('click', ()=>{ state.weekOffset--; render(); });
  if(wkNext) wkNext.addEventListener('click', ()=>{ state.weekOffset++; render(); });

  ['audience','format','status'].forEach(key=>{
    const sel = document.getElementById('f-'+key);
    if(sel) sel.addEventListener('change', ()=>{ state.filters[key]=sel.value; render(); });
  });
  const clearBtn = document.getElementById('f-clear');
  if(clearBtn) clearBtn.addEventListener('click', ()=>{ state.filters={audience:'todos',format:'todos',status:'todos'}; render(); });

  document.querySelectorAll('[data-period]').forEach(b=>{
    b.addEventListener('click', ()=>{ state.balancePeriod=b.dataset.period; render(); });
  });

  document.querySelectorAll('[data-day-tab]').forEach(b=>{
    b.addEventListener('click', ()=>{ state.activeDayTab=b.dataset.dayTab; render(); });
  });

  document.querySelectorAll('[data-open]').forEach(b=>{
    b.addEventListener('click', ()=> openModal(b.dataset.open));
  });
}

/* ============================================================
   BOOT
   ============================================================ */
async function bootData(){
  state.loading = true; render();
  state.contents = await loadContents();
  state.loading = false;
  render();
}

async function init(){
  render();
  const info = await loadSessionAndProfile();
  if(info && info.role){
    state.session = info.session; state.role = info.role; state.displayName = info.displayName;
    await bootData();
  } else {
    state.loading = false;
    render();
  }
}
init();
