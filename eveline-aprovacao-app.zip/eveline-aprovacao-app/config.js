// Cole aqui as credenciais do SEU projeto Supabase.
// Elas ficam em: Supabase → seu projeto → Project Settings → API.
// A "anon key" é pública por natureza (segura de expor no front-end) —
// quem protege os dados de verdade são as regras de RLS do schema.sql.

window.SUPABASE_URL = "COLE_AQUI_A_SUA_PROJECT_URL";
window.SUPABASE_ANON_KEY = "COLE_AQUI_A_SUA_ANON_KEY";
