-- ============================================================
-- Schema do sistema de aprovação de conteúdos — Eveline Zati
-- Execute este arquivo inteiro em: Supabase → seu projeto → SQL Editor → New query
-- ============================================================

-- Extensão necessária para gerar UUIDs
create extension if not exists "pgcrypto";

-- ---------- Tabela de conteúdos ----------
create table if not exists public.contents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  weekday text not null check (weekday in ('segunda','quarta','sexta')),
  date date not null,
  audience text not null check (audience in ('cliente_final','mentoria','conexao')),
  format text not null check (format in ('Foto','Carrossel','Reels','Vídeo','Frase','Stories','Outro')),
  drive_link text,
  caption text default '',
  caption_suggestion text default '',
  status text not null default 'aguardando_aprovacao'
    check (status in ('aguardando_aprovacao','ajustes_solicitados','aprovado','publicado')),
  is_seed boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ---------- Histórico de cada conteúdo (aprovações, ajustes, edições) ----------
create table if not exists public.content_history (
  id uuid primary key default gen_random_uuid(),
  content_id uuid not null references public.contents(id) on delete cascade,
  type text not null,
  text text not null,
  author text not null,
  created_at timestamptz default now()
);

-- ---------- Perfis: liga cada usuário do Supabase Auth a um papel ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','eveline')),
  display_name text
);

-- ============================================================
-- RLS (Row Level Security)
-- Sistema privado de 2 pessoas: qualquer usuário autenticado
-- (criado manualmente por você no painel do Supabase) pode
-- ler e escrever. Usuários anônimos não acessam nada.
-- ============================================================
alter table public.contents enable row level security;
alter table public.content_history enable row level security;
alter table public.profiles enable row level security;

create policy "authenticated read contents" on public.contents
  for select using (auth.role() = 'authenticated');
create policy "authenticated insert contents" on public.contents
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated update contents" on public.contents
  for update using (auth.role() = 'authenticated');
create policy "authenticated delete contents" on public.contents
  for delete using (auth.role() = 'authenticated');

create policy "authenticated read history" on public.content_history
  for select using (auth.role() = 'authenticated');
create policy "authenticated insert history" on public.content_history
  for insert with check (auth.role() = 'authenticated');

create policy "authenticated read profiles" on public.profiles
  for select using (auth.role() = 'authenticated');

-- ============================================================
-- Depois de criar os dois usuários em
-- Authentication → Users → Add user (um para o administrador,
-- um para a Eveline), rode os inserts abaixo trocando os UUIDs
-- pelo "User UID" de cada um (aparece na lista de usuários).
-- ============================================================
-- insert into public.profiles (id, role, display_name) values
--   ('COLE-O-UUID-DO-USUARIO-ADMIN', 'admin', 'Administrador'),
--   ('COLE-O-UUID-DO-USUARIO-EVELINE', 'eveline', 'Eveline Zati');

-- ============================================================
-- Dados de exemplo (opcionais) — descomente para ver o painel
-- populado logo de início. Marque isEve como is_seed = true.
-- ============================================================
-- insert into public.contents (title, weekday, date, audience, format, drive_link, caption, status, is_seed) values
-- ('Duas pessoas podem ter o mesmo peso', 'segunda', current_date - extract(dow from current_date)::int + 1, 'cliente_final', 'Carrossel', 'https://drive.google.com/', 'Duas pessoas podem ter o mesmo peso na balança e histórias completamente diferentes por trás dele.', 'aguardando_aprovacao', true),
-- ('Como precificar sua consulta com segurança', 'quarta', current_date - extract(dow from current_date)::int + 3, 'mentoria', 'Vídeo', 'https://drive.google.com/', 'Precificar não é sobre cobrar mais — é sobre entender o valor real do seu trabalho.', 'aprovado', true),
-- ('Um domingo qualquer em casa', 'sexta', current_date - extract(dow from current_date)::int + 5, 'conexao', 'Foto', 'https://drive.google.com/', 'Nem todo conteúdo precisa ensinar algo.', 'ajustes_solicitados', true);
